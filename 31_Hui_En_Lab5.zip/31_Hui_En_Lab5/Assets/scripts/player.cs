﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class player : MonoBehaviour
{
    public int speed;
    public int coincount;
    public Scene scene;
    // Start is called before the first frame update
    void Start()
    {
        coincount = GameObject.FindGameObjectsWithTag("coin").Length;
        scene=SceneManager.GetActiveScene();
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position = new Vector3(Mathf.Clamp(transform.position.x,-9f,9f),0, Mathf.Clamp(transform.position.z,-5.5f,5.5f));

        if (Input.GetKey(KeyCode.W))
        {
            this.transform.position +=  transform.forward * speed* Time.deltaTime ;
        }
        if (Input.GetKey(KeyCode.S))
        {
            this.transform.position -= transform.forward * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            this.transform.position += transform.right * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.A))
        {
            this.transform.position -= transform.right * speed * Time.deltaTime;
        }
        if (coincount<=0)
        {
            if (scene.name=="L1")
            {
                SceneManager.LoadScene("L2");
            }
            else
            {
                SceneManager.LoadScene("win");
            }
            
        }
    }
    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "coin")
        {
            Destroy(other.gameObject);
            coincount--;
        }
        if (other.gameObject.tag == "obst")
        {
            SceneManager.LoadScene("lose");
        }
    }
}
